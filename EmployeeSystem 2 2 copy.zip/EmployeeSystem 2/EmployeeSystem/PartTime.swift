//
//  PartTime.swift
//  EmployeeSystem
//
//  Created by MacStudent on 2018-08-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class PartTime
{
    var rate: Double
    var hoursWorked: Double
    //var vehicle : Vehicle
    init(empname: String ,age : Int, rate: Double, hoursWorked: Double) {
        
        self.rate = rate
        self.hoursWorked = hoursWorked
        // self.vehicle = vehicle
        //super.init(empName: empname, age: age)
    }
    func PrintMyData() {
        
        PrintMyData()
        
        print("Rate : \(rate) \n Hours Worked : \(hoursWorked)")
    }
}
