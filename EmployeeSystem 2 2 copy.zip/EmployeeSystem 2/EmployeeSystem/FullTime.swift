//
//  FullTime.swift
//  EmployeeSystem
//
//  Created by MacStudent on 2018-08-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class FullTime
{
    var salary : Double!
    var bonus  : Double!
    init(empname: String ,age : Int, salary:Double,bonus:Double)
    {
        
        self.salary=salary
        self.bonus=bonus
        //super(empName: empname, age: age)
    }
    func calcEarnings() -> Double
    {
        return salary+bonus
    }
    
    func PrintMyData() {
        
        PrintMyData()
        
        print("Total salary : \(calcEarnings())")
        print("Employee has a car")
    }
    
}
