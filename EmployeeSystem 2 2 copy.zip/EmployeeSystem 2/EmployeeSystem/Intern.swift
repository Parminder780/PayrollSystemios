//
//  Intern.swift
//  EmployeeSystem
//
//  Created by MacStudent on 2018-08-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class intern
{
    var schoolName: String?
    // var courseName: String?
    
    init(empname: String ,age : Int,schoolName: String)
    {
        
        self.schoolName = schoolName
        // self.courseName = courseName
        //super(empName: empname, age: age)
        
    }
    func PrintMyData() {
        
        PrintMyData()
        
        print("School name : \(schoolName!)" )
        print("Employee has a Motorcycle")
        
    }
}
